# Felifrío · Promotion v2

Video vertical de 65 segundos. Remotion 4.0.538, React, 1080×1920 a 30 fps.

## Edición

- `npm ci`
- `npm run dev -- --no-open`
- Abrir la composición `Felifrio-Promotion` en Studio. Cada escena tiene su propia composición editable.
- Exportar: `npx remotion render Felifrio-Promotion out/Felifrio_Promotion_v2.mp4 --crf=18`.
- En este entorno se usó `--browser-executable=/usr/bin/chromium --concurrency=2`.

## Dirección de edición

Titulares Anton, textos Manrope; blanco/negro, azul intenso y acentos lima. Texto importante sobre fondos sólidos. Planos de la app con entradas, movimientos de cámara y acercamientos. Transiciones de 15 frames y música a 120 BPM con efectos de barrido y confirmación.

## Materiales

Capturas y clips reales de la aplicación, con datos ficticios. Las cifras del ejemplo son: 200 bolsas producidas, 40 entregadas, 15 restantes, 25 vendidas a un precio ilustrativo de $1.000, cobro de $20.000 y deuda de $5.000. Reponer 20 deja 35 bolsas y no genera una venta nueva. No se grabaron datos de producción.

La música y los efectos fueron sintetizados para esta pieza (`soundtrack.py`). No tiene locución. Las fuentes incluyen su licencia OFL.

`capture.py` requiere una instancia local de prueba vacía: no debe ejecutarse contra una base real. Para reeditar el video basta con los materiales de `public/`, sin repetir la captura.
