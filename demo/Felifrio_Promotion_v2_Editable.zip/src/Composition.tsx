import {Composition,Folder,useVideoConfig,staticFile} from 'remotion';
import {Audio} from '@remotion/media';
import {TransitionSeries,springTiming} from '@remotion/transitions';
import {slide} from '@remotion/transitions/slide';
import {wipe} from '@remotion/transitions/wipe';
import {Hook} from './scenes/Hook';import {Brand} from './scenes/Brand';import {Production} from './scenes/Production';import {Load} from './scenes/Load';import {Delivery} from './scenes/Delivery';import {Count} from './scenes/Count';import {Collect} from './scenes/Collect';import {Result} from './scenes/Result';import {Restock} from './scenes/Restock';import {More} from './scenes/More';import {Close} from './scenes/Close';

export function Promo(){const {fps}=useVideoConfig();return <>
 <Audio src={staticFile('soundtrack.wav')} premountFor={fps}/>
 <TransitionSeries>
  <TransitionSeries.Sequence name="El hielo se mueve" durationInFrames={120} premountFor={fps}><Hook/></TransitionSeries.Sequence>
  <TransitionSeries.Transition presentation={slide({direction:'from-bottom'})} timing={springTiming({durationInFrames:15,config:{damping:200}})}/>
  <TransitionSeries.Sequence name="Tu negocio en una app" durationInFrames={150} premountFor={fps}><Brand/></TransitionSeries.Sequence>
  <TransitionSeries.Transition presentation={wipe({direction:'from-left'})} timing={springTiming({durationInFrames:15,config:{damping:200}})}/>
  <TransitionSeries.Sequence name="Producción" durationInFrames={210} premountFor={fps}><Production/></TransitionSeries.Sequence>
  <TransitionSeries.Transition presentation={slide({direction:'from-right'})} timing={springTiming({durationInFrames:15,config:{damping:200}})}/>
  <TransitionSeries.Sequence name="Carga de reparto" durationInFrames={180} premountFor={fps}><Load/></TransitionSeries.Sequence>
  <TransitionSeries.Transition presentation={wipe({direction:'from-bottom'})} timing={springTiming({durationInFrames:15,config:{damping:200}})}/>
  <TransitionSeries.Sequence name="Consignación" durationInFrames={180} premountFor={fps}><Delivery/></TransitionSeries.Sequence>
  <TransitionSeries.Transition presentation={slide({direction:'from-left'})} timing={springTiming({durationInFrames:15,config:{damping:200}})}/>
  <TransitionSeries.Sequence name="Recuento y rendición" durationInFrames={240} premountFor={fps}><Count/></TransitionSeries.Sequence>
  <TransitionSeries.Transition presentation={wipe({direction:'from-right'})} timing={springTiming({durationInFrames:15,config:{damping:200}})}/>
  <TransitionSeries.Sequence name="Cobro parcial" durationInFrames={210} premountFor={fps}><Collect/></TransitionSeries.Sequence>
  <TransitionSeries.Transition presentation={slide({direction:'from-bottom'})} timing={springTiming({durationInFrames:15,config:{damping:200}})}/>
  <TransitionSeries.Sequence name="Estado del negocio" durationInFrames={210} premountFor={fps}><Result/></TransitionSeries.Sequence>
  <TransitionSeries.Transition presentation={wipe({direction:'from-left'})} timing={springTiming({durationInFrames:15,config:{damping:200}})}/>
  <TransitionSeries.Sequence name="Reposición" durationInFrames={150} premountFor={fps}><Restock/></TransitionSeries.Sequence>
  <TransitionSeries.Transition presentation={slide({direction:'from-right'})} timing={springTiming({durationInFrames:15,config:{damping:200}})}/>
  <TransitionSeries.Sequence name="Más funciones reales" durationInFrames={240} premountFor={fps}><More/></TransitionSeries.Sequence>
  <TransitionSeries.Transition presentation={wipe({direction:'from-bottom'})} timing={springTiming({durationInFrames:15,config:{damping:200}})}/>
  <TransitionSeries.Sequence name="Felifrío" durationInFrames={210} premountFor={fps}><Close/></TransitionSeries.Sequence>
 </TransitionSeries>
 </>}
export const MyComposition=()=> <>
 <Composition id="Felifrio-Promotion" component={Promo} width={1080} height={1920} fps={30} durationInFrames={1950}/>
 <Folder name="Escenas">
 <Composition id="Hook" component={Hook} width={1080} height={1920} fps={30} durationInFrames={120}/>
 <Composition id="Brand" component={Brand} width={1080} height={1920} fps={30} durationInFrames={150}/>
 <Composition id="Production" component={Production} width={1080} height={1920} fps={30} durationInFrames={210}/>
 <Composition id="Load" component={Load} width={1080} height={1920} fps={30} durationInFrames={180}/>
 <Composition id="Delivery" component={Delivery} width={1080} height={1920} fps={30} durationInFrames={180}/>
 <Composition id="Count" component={Count} width={1080} height={1920} fps={30} durationInFrames={240}/>
 <Composition id="Collect" component={Collect} width={1080} height={1920} fps={30} durationInFrames={210}/>
 <Composition id="Result" component={Result} width={1080} height={1920} fps={30} durationInFrames={210}/>
 <Composition id="Restock" component={Restock} width={1080} height={1920} fps={30} durationInFrames={150}/>
 <Composition id="More" component={More} width={1080} height={1920} fps={30} durationInFrames={240}/>
 <Composition id="Close" component={Close} width={1080} height={1920} fps={30} durationInFrames={210}/>
 </Folder>
 </>;
