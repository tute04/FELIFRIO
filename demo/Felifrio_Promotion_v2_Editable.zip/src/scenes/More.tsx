import {Sequence,useVideoConfig} from 'remotion';
import {Stage,Title,Phone,Pill,C} from '../design';
export function More(){const {fps}=useVideoConfig();return <>
 <Sequence durationInFrames={Math.round(2.6*fps)} premountFor={fps}><Stage tone="blue"><Title lines={['¿HUBO PÉRDIDAS?','QUEDAN ANOTADAS.']} size={104}/><Phone video="10-loss" trim={1.1} top={540} width={840}/><Pill top={1600} delay={15} size={45}>Registrá el motivo. Resolvé después.</Pill></Stage></Sequence>
 <Sequence from={Math.round(2.6*fps)} durationInFrames={Math.round(2.7*fps)} premountFor={fps}><Stage><Title lines={['COMPRAS Y PAGOS.','SIN PERDER EL HILO.']} size={106}/><Phone video="11-purchase" trim={4.5} top={540} width={840} tilt={-3}/><Pill top={1590} delay={10} bg={C.blue} color="white" size={44}>Importe, pago y saldo pendiente.</Pill></Stage></Sequence>
 <Sequence from={Math.round(5.3*fps)} durationInFrames={Math.round(2.7*fps)} premountFor={fps}><Stage tone="dark"><Title lines={['LO PENDIENTE.','CON RESPONSABLE.']} size={110}/><Phone video="12-task" trim={2.5} top={540} width={840} tilt={3}/><Pill top={1600} delay={10} size={48}>Tareas con fecha y responsable.</Pill></Stage></Sequence>
 </>}
