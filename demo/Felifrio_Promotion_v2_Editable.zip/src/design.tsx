import React from 'react';
import {AbsoluteFill,CanvasImage,interpolate,spring,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import {loadFont} from '@remotion/fonts';
import {Video} from '@remotion/media';

loadFont({family:'Anton',url:staticFile('fonts/Anton.ttf'),weight:'400'});
loadFont({family:'Manrope',url:staticFile('fonts/Manrope.ttf'),weight:'100 900'});
export const C={ink:'#10131c',blue:'#0754ef',white:'#ffffff',paper:'#f3f5f9',lime:'#e5fc50'};
export const clamp={extrapolateLeft:'clamp',extrapolateRight:'clamp'} as const;
export const Snow=({size=50,color='currentColor'}:{size?:number;color?:string})=><svg width={size} height={size} viewBox="0 0 48 48" fill="none" stroke={color} strokeWidth="3.2" strokeLinecap="round"><path d="M24 3v42M6 13l36 22M6 35l36-22M16 8l8 8 8-8M16 40l8-8 8 8M5 22l11-3-2-11M43 26l-11 3 2 11M5 26l11 3-2 11M43 22l-11-3 2-11"/></svg>;
export function Stage({children,tone='light',tag='GESTIÓN DEL NEGOCIO'}:{children:React.ReactNode;tone?:'light'|'blue'|'dark';tag?:string}) {
 const color=tone==='light'?C.ink:C.white;
 return <AbsoluteFill style={{background:tone==='light'?C.paper:tone==='blue'?C.blue:C.ink,color,fontFamily:'Manrope',overflow:'hidden'}}>
  <div style={{position:'absolute',left:80,top:90,display:'flex',alignItems:'center',gap:18,fontWeight:850,fontSize:40,letterSpacing:-1}}><Snow/>FELIFRÍO</div>
  <div style={{position:'absolute',right:80,top:102,fontSize:25,fontWeight:800,letterSpacing:2}}>EN ACCIÓN</div>
  {children}
  <div style={{position:'absolute',left:80,right:80,bottom:65,fontSize:25,fontWeight:750,letterSpacing:1.5,display:'flex',justifyContent:'space-between',zIndex:100}}><span>DEMO · DATOS FICTICIOS</span><span>{tag}</span></div>
 </AbsoluteFill>;
}
export function Title({lines,top=220,size=120,color,delay=0,left=80}:{lines:string[];top?:number;size?:number;color?:string;delay?:number;left?:number}) {
 const f=useCurrentFrame(),{fps}=useVideoConfig();
 return <div style={{position:'absolute',top,left,right:70,fontFamily:'Anton',fontSize:size,lineHeight:1.02,letterSpacing:-1,color,zIndex:20}}>{lines.map((line,i)=><div key={i} style={{overflow:'hidden',paddingBottom:9}}><div style={{translate:`0 ${interpolate(spring({frame:f-delay-i*3,fps,config:{damping:22,stiffness:190}}),[0,1],[130,0])}%`}}>{line}</div></div>)}</div>;
}
export function Phone({image,video,top=540,left=120,width=840,tilt=0,zoom=1,trim=.4}:{image?:string;video?:string;top?:number;left?:number;width?:number;tilt?:number;zoom?:number;trim?:number}) {
 const f=useCurrentFrame(),{fps}=useVideoConfig();
 const height=width*(video?702/468:760/468);
 return <div style={{position:'absolute',left,top,width,height,border:`12px solid ${C.ink}`,borderRadius:50,overflow:'hidden',background:'white',boxShadow:'0 40px 100px #00000035',
  scale:interpolate(spring({frame:f-5,fps,config:{damping:24,stiffness:120}}),[0,1],[.8,zoom])*interpolate(f,[0,55,90,180],[1,1,1.06,1.025],clamp),
  translate:`${interpolate(f,[0,30,200],[120,0,-20],clamp)}px ${interpolate(f,[0,30],[100,0],clamp)}px`,
  rotate:`${interpolate(f,[0,30,210],[tilt+7,tilt,tilt-1],clamp)}deg`,transformOrigin:'50% 60%'}}>
  {image?<CanvasImage src={staticFile('shots/'+image+'.png')} style={{width:'100%',height:'100%',objectFit:'cover',filter:'contrast(1.08)'}}/>:null}
  {video?<Video src={staticFile('clips/'+video+'.mp4')} muted trimBefore={Math.round(trim*fps)} premountFor={fps} style={{width:'100%',height:'100%',objectFit:'cover'}}/>:null}
 </div>;
}
export function Pill({children,top,left=80,bg=C.lime,color=C.ink,size=44,delay=0}:{children:React.ReactNode;top:number;left?:number;bg?:string;color?:string;size?:number;delay?:number}) {
 const f=useCurrentFrame(),{fps}=useVideoConfig();
 return <div style={{position:'absolute',left,top,padding:'20px 32px',borderRadius:18,background:bg,color,fontSize:size,fontWeight:850,zIndex:50,
 scale:spring({frame:f-delay,fps,config:{damping:17,stiffness:160}}),boxShadow:'0 12px 35px #00000016'}}>{children}</div>;
}
export function Counter({value,prefix='',suffix='',size=200,delay=10}:{value:number;prefix?:string;suffix?:string;size?:number;delay?:number}) {
 const f=useCurrentFrame();const n=Math.round(interpolate(f,[delay,delay+26],[0,value],clamp));
 return <span style={{fontFamily:'Anton',fontSize:size,letterSpacing:-3,lineHeight:1}}>{prefix}{n.toLocaleString('es-AR')}{suffix}</span>;
}
export function Bag({x,y,size=150,rotate=0,delay=0}:{x:number;y:number;size?:number;rotate?:number;delay?:number}){
 const f=useCurrentFrame(),{fps}=useVideoConfig();
 return <div style={{position:'absolute',left:x,top:y,width:size,height:size*1.3,background:'linear-gradient(140deg,#fff,#cbe9ff)',border:'3px solid white',borderRadius:'18px 18px 32px 32px',boxShadow:'0 22px 40px #00000025',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',color:C.blue,gap:8,
 translate:`0 ${interpolate(spring({frame:f-delay,fps,config:{damping:15}}),[0,1],[700,0])+Math.sin(f/20+delay)*12}px`,rotate:`${rotate+Math.sin(f/30)*4}deg`}}><Snow size={size*.35}/><b style={{fontSize:size*.22}}>3 KG</b></div>;
}
