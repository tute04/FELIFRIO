from playwright.sync_api import sync_playwright
from pathlib import Path
import urllib.request,json,uuid
out=Path('/workspace/FELIFRIO/outputs/promo-v2/public/shots');base='http://127.0.0.1:8789'
def act(action):
 s=json.load(urllib.request.urlopen(base+'/api/data'))
 req=urllib.request.Request(base+'/api/data',data=json.dumps({'operationId':str(uuid.uuid4()),'revision':s['revision'],'action':action}).encode(),headers={'Content-Type':'application/json'})
 return json.load(urllib.request.urlopen(req))['state']
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 studio=b.new_page();studio.goto('http://localhost:3005');studio.wait_for_timeout(1000);print('Studio loaded:',studio.title(),flush=True)
 page=b.new_page(viewport={'width':468,'height':760},device_scale_factor=3)
 def fresh(tab):
  page.goto(base);page.get_by_text('Cargando el negocio…').wait_for(state='hidden');page.locator('nav').get_by_role('button',name=tab,exact=True).click()
 def snap(name):page.screenshot(path=str(out/(name+'.png')))
 def modal(tab,button):fresh(tab);page.get_by_role('button',name=button,exact=True).click()
 state=act({'type':'client','name':'Almacén Las Sierras','price':1000});cid=state['clients'][0]['id']
 modal('Producción','Nuevo lote');page.get_by_label('Nombre o código del lote').fill('LOTE DEMO 01');page.get_by_label('Cantidad de bolsas de 3 kg').fill('200');snap('production-form')
 act({'type':'production','batch':'LOTE DEMO 01','quantity':200});fresh('Producción');snap('production')
 act({'type':'load','quantity':40});fresh('Repartos');snap('loaded')
 modal('Repartos','Entregar a cliente');page.locator('select').first.select_option(label='Almacén Las Sierras');page.get_by_label('Cantidad de bolsas de 3 kg').fill('40');snap('delivery-form')
 act({'type':'delivery','clientId':cid,'quantity':40})
 modal('Rendiciones','Nueva rendición');page.locator('select').first.select_option(label='Almacén Las Sierras');page.get_by_label('Bolsas que quedan en el comercio').fill('15');snap('settlement-form')
 act({'type':'settlement','clientId':cid,'counted':15,'loss':0})
 modal('Rendiciones','Registrar cobro');page.locator('select').first.select_option(label='Almacén Las Sierras');page.get_by_label('Importe cobrado ($)').fill('20000');page.locator('select').last.select_option(label='Efectivo');snap('collect-form')
 act({'type':'collect','clientId':cid,'amount':20000,'method':'Efectivo'});fresh('Inicio');snap('dashboard')
 fresh('Clientes');snap('client')
 b.close()
