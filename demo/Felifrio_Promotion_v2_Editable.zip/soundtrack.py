import numpy as np,wave,subprocess
from pathlib import Path
sr=44100;dur=65;n=sr*dur;beat=.5;rng=np.random.default_rng(48)
track=np.zeros((n,2),np.float32)
def add(sound,at,vol=1,pan=0):
 start=int(at*sr);end=min(n,start+len(sound))
 if end<=start:return
 x=sound[:end-start]*vol
 track[start:end,0]+=x*np.sqrt((1-pan)/2);track[start:end,1]+=x*np.sqrt((1+pan)/2)
def hz(note):return 440*2**((note-69)/12)
def synth(note,length,kind):
 t=np.arange(int(length*sr))/sr;f=hz(note)
 if kind=='kick':return np.sin(2*np.pi*(48*t+9*(1-np.exp(-t*35))))*np.exp(-t*9)+rng.normal(0,1,len(t))*np.exp(-t*180)*.1
 if kind=='hat':
  a=rng.normal(0,1,len(t));return (a-np.roll(a,1))*.12*np.exp(-t*65)
 if kind=='snare':return (rng.normal(0,1,len(t))*.28+np.sin(2*np.pi*180*t)*.17)*np.exp(-t*22)
 if kind=='bass':return (np.sin(2*np.pi*f*t)+.24*np.sin(2*np.pi*f*2*t))*np.minimum(1,t*100)*np.exp(-t*5)*.6
 if kind=='lead':
  a=sum(np.sin(2*np.pi*f*k*t)/k**1.4 for k in range(1,7));return a*np.minimum(1,t*220)*np.exp(-t*9)*.21
 if kind=='pad':
  a=sum(np.sin(2*np.pi*f*det*t) for det in [.997,1,1.003])/3
  pump=(.3+.7*np.minimum(1,(t%beat)/.18));return a*np.minimum(1,t*20)*np.minimum(1,(length-t)/.5)*pump*.13
chords=[[41,48,53,56],[37,44,49,53],[44,51,56,60],[39,46,51,55]]
melody=[12,19,24,22,19,15,17,19]
for b in range(int(dur/beat)):
 at=b*beat;ch=chords[(b//8)%4];energy=.8 if at<4 else 1
 # A short breakdown around the counting formula keeps the musical arc moving.
 if not 28<at<30:add(synth(0,.5,'kick'),at,.65*energy)
 if b%2:add(synth(0,.23,'snare'),at,.66*energy)
 add(synth(0,.11,'hat'),at+.25,.75,pan=.28)
 if b%2==0:add(synth(0,.06,'hat'),at+.375,.3,pan=-.4)
 if b%2==0:add(synth(ch[0]-0,.7,'bass'),at,.75)
 if b%4==0:
  for note in ch[1:]:add(synth(note,2.1,'pad'),at,.7)
 note=ch[0]+melody[b%8]
 add(synth(note,.55,'lead'),at+.25,.75,pan=-.18)
 add(synth(note,.55,'lead'),at+.625,.19,pan=.4)
# Designed impact/air sweeps match the 0.5-second scene transitions.
for at in [3.5,8,14.5,20,25.5,33,39.5,46,50.5,58,53.1,55.8]:
 length=.55;t=np.arange(int(length*sr))/sr
 noise=rng.normal(0,1,len(t));noise=np.convolve(noise,np.ones(9)/9,mode='same')
 whoosh=(noise*.65+np.sin(2*np.pi*(350*t+1200*t*t))*.04)*np.sin(np.pi*t/length)**2
 add(whoosh,max(0,at-.27),.6)
 add(synth(0,.5,'kick'),at,.38)
# Confirmation tones timed to the result reveals, softer than the music.
for at in [11,23,29.5,36.5,42]:
 t=np.arange(int(.7*sr))/sr;ding=(np.sin(2*np.pi*1046*t)+.4*np.sin(2*np.pi*1568*t))*np.exp(-t*8)*.11;add(ding,at,.7)
fade=np.minimum(1,np.arange(n)/sr/.25)*np.minimum(1,(n-1-np.arange(n))/sr/1.4)
track=np.tanh(track*1.2)*fade[:,None]*.8
with wave.open('public/track-raw.wav','wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((track*32767).astype('<i2').tobytes())
subprocess.run(['ffmpeg','-v','error','-y','-i','public/track-raw.wav','-af','loudnorm=I=-15:TP=-1.5:LRA=8','-ar','44100','public/soundtrack.wav'],check=True)
print('65-second original score ready')
