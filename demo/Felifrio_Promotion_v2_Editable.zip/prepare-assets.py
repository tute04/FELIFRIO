from pathlib import Path
import subprocess,concurrent.futures
p=Path('/workspace/FELIFRIO/outputs/video');out=Path('public/clips');out.mkdir(exist_ok=True)
names=['03-production','04-load','05-delivery','06-settlement','07-collect','09-restock','10-loss','11-purchase','12-task']
def convert(name):
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(p/(name+'.webm')),'-vf','crop=468:702:0:0,eq=contrast=1.04:saturation=1.05','-an','-c:v','libx264','-preset','fast','-crf','16','-pix_fmt','yuv420p','-movflags','+faststart',str(out/(name+'.mp4'))],check=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(convert,names))
print('Clips prepared')
